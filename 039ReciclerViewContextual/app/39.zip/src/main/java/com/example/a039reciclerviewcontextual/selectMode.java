package com.example.a039reciclerviewcontextual;

public interface selectMode {
    void Onselec();

}
